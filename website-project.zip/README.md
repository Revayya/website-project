# TEJAS MADE — Premium Custom Merchandise, Corporate Gifts & School Uniforms

> **"CUSTOM MADE. JUST FOR YOU."**

A complete, high-performance, responsive e-commerce web application created using **strictly HTML5, CSS3, and Vanilla JavaScript (ES6+)**. No frameworks, no external libraries, no Node.js runtime, and no backend or database required. It runs instantly by opening `index.html` in any web browser.

---

## 📞 Official Business Contacts

- **Phone / WhatsApp**: [+91 9606799579](https://wa.me/919606799579)
- **Email**: [tejasmadeofficial@gmail.com](mailto:tejasmadeofficial@gmail.com)
- **Instagram**: [@tejasmade_official](https://instagram.com/tejasmade_official)
- **Facility Address**: 2/7, Lovely Pan Wali Gali, Sanoli Road, Near Sanjay Chowk, Panipat, Haryana - 132103

---

## 🌟 What's New & Key Updates

1. **Sliding Posters Spotlight on Home Page**:
   - Dynamic sliding carousel highlighting 4 core product categories:
     - *Custom Apparel & Hoodies* (`poster-apparel.jpg`)
     - *Corporate Executive Gift Hampers* (`poster-corporate.jpg`)
     - *School & Academy Uniforms* (`poster-uniform.jpg`)
     - *Magic Sublimation Mugs & LED Frames* (`poster-mugs.jpg`)
   - Features auto-play every 5 seconds, previous/next arrow navigation, interactive slide indicator dots, and pause-on-hover.

2. **Animated "WEAR YOUR STORY."**:
   - Eye-catching metallic gold light reflection sweep and breathing aura using pure CSS keyframes (`metallicShine` and `titleGlowPulse`).

3. **Updated Collections & Images**:
   - **Corporate Gifts** (replaces Business Startups) with high-res executive gift hamper image (`col-corporate-gifts.jpg`).
   - **School Uniform** (replaces Sublimation Lamps) with high-res school polo and uniform image (`col-school-uniform.jpg`).

4. **Product Prices Hidden**:
   - Fixed prices removed across catalog cards, quick view modal, search, and customizer.
   - Replaced with direct **"Order on WhatsApp"** and **"Custom Quote on Inquiry"** badges to support flexible wholesale and custom volume pricing.

5. **WhatsApp Ordering Integration (9606799579)**:
   - Floating WhatsApp Hotline button at the bottom of the screen.
   - All product cards, custom studio, quick view modals, and inquiry drawers format a comprehensive custom order draft pre-addressed to `9606799579`.

---

## 📁 Project Folder Structure

```
website-project/
├── index.html                      # Main semantic HTML5 webpage
├── README.md                       # Documentation & offline usage guide
├── css/
│   ├── style.css                   # Master stylesheet (theme, posters, animated title)
│   └── responsive.css              # Media queries (mobile, tablet, desktop)
├── js/
│   └── main.js                     # Vanilla JS controller (slider, WhatsApp drafts, modals)
└── assets/
    ├── icons/                      # Scalable SVG icons
    │   ├── cart.svg
    │   ├── close.svg
    │   ├── instagram.svg
    │   ├── search.svg
    │   ├── user.svg
    │   └── whatsapp.svg
    └── images/                     # Offline image assets
        ├── logo.png                # Official brand logo
        ├── logo.jpg                # 3D Gold & Silver full logo with tagline
        ├── logo-icon.jpg           # TM monogram crest badge
        ├── hero-banner.jpeg        # Workshop hero background
        ├── poster-apparel.jpg      # Home poster: Custom Apparel
        ├── poster-corporate.jpg    # Home poster: Corporate Gifts
        ├── poster-uniform.jpg      # Home poster: School Uniforms
        ├── poster-mugs.jpg         # Home poster: Sublimation Mugs
        ├── col-corporate-gifts.jpg # Corporate Gifts collection
        ├── col-school-uniform.jpg  # School Uniform collection
        ├── col-mugs.webp           # Sublimation Mugs collection
        ├── col-bottles.webp        # Sublimation Bottles & Sippers
        ├── col-fabrics.webp        # Warm Hoodies & Fabrics
        ├── col-led-frames.webp     # Optical Acrylic LED Frames
        ├── col-tshirts.webp        # Classic Custom T-Shirts
        ├── col-machines.webp       # 5-in-1 Heat Press Machines
        ├── col-keyrings.webp       # Double-Sided Metal Keychains
        ├── col-wooden.webp         # Laser Engraved Wooden Stands
        ├── col-marking.webp        # Custom Badges & Caps
        └── col-magnets.webp        # Sequin Cushions & Magnets
```

---

## 🚀 How to Run Locally

1. Open your file explorer and navigate to:
   `C:\Users\hp\.gemini\antigravity\scratch\website-project`
2. Double-click `index.html` to open it in **Google Chrome**, **Microsoft Edge**, **Firefox**, or **Safari**.
3. **No server or setup required**: Everything is self-contained and loads directly from local files.

---

*© 2026 TEJAS MADE. Custom Made. Just For You.*
