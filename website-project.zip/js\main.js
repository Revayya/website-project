/**
 * TEJAS MADE — Custom Made. Just For You.
 * Master Frontend Controller (Vanilla JavaScript ES6+)
 * Updated with:
 * - Phone/WhatsApp: 9606799579
 * - Email: tejasmadeofficial@gmail.com
 * - Instagram: @tejasmade_official
 * - Corporate Gifts & School Uniform Collections
 * - Hidden Product Prices (Replaced by WhatsApp Direct Inquiry & Factory Quotes)
 * - Home Page Sliding Posters Carousel
 */

(function () {
  'use strict';

  const BUSINESS_PHONE = '9606799579';
  const BUSINESS_EMAIL = 'tejasmadeofficial@gmail.com';
  const BUSINESS_INSTA = 'tejasmade_official';

  // =========================================================================
  // 1. DATA SOURCE: Collections & Products Catalog (NO PUBLIC PRICES)
  // =========================================================================
  const PRODUCTS_DATA = [
    {
      id: 'tm-101',
      title: 'Classic Custom T-Shirt',
      category: 'apparel',
      categoryName: 'Apparel & Uniforms',
      collection: 'col-tshirts',
      rating: 4.9,
      reviewsCount: 142,
      badge: 'Bestseller',
      image: 'assets/images/col-tshirts.webp',
      desc: '100% bio-washed cotton, 220 GSM breathable fabric. Fully customizable with your logo, school/team badge, photo or slogan.',
      sizes: ['S', 'M', 'L', 'XL', 'XXL'],
      colors: ['Obsidian Black', 'Pure White', 'Navy Blue', 'Charcoal Grey'],
      isCustomizable: true
    },
    {
      id: 'tm-102',
      title: 'Premium Custom Hoodie',
      category: 'apparel',
      categoryName: 'Apparel & Uniforms',
      collection: 'col-fabrics',
      rating: 4.8,
      reviewsCount: 96,
      badge: 'Popular',
      image: 'assets/images/col-fabrics.webp',
      desc: 'Heavyweight 350 GSM warm fleece interior hoodie with kangaroo pouch pockets and high-definition chest/back print.',
      sizes: ['M', 'L', 'XL', 'XXL'],
      colors: ['Jet Black', 'Heather Grey', 'Imperial Gold', 'Navy'],
      isCustomizable: true
    },
    {
      id: 'tm-103',
      title: 'Corporate Executive Gift Hamper Box',
      category: 'corporate',
      categoryName: 'Corporate Gifts',
      collection: 'col-corporate-gifts',
      rating: 5.0,
      reviewsCount: 88,
      badge: 'Corporate Choice',
      image: 'assets/images/col-corporate-gifts.jpg',
      desc: 'Luxury branded gift box containing engraved vacuum temperature bottle, leather finish notebook, metal pen & custom keychain.',
      sizes: ['Standard Executive Set', 'Premium VIP Box'],
      colors: ['Matte Black Gold', 'Deep Navy Silver', 'Tan Brown'],
      isCustomizable: true
    },
    {
      id: 'tm-104',
      title: 'Premium School & Academy Uniform Polo / Shirt',
      category: 'uniforms',
      categoryName: 'School Uniform',
      collection: 'col-school-uniform',
      rating: 4.9,
      reviewsCount: 114,
      badge: 'Bulk Uniforms',
      image: 'assets/images/col-school-uniform.jpg',
      desc: 'Durable, colorfast cotton-poly blend school uniform shirts and polo tees with custom embroidered school crest and house colors.',
      sizes: ['Ages 4-6', 'Ages 7-10', 'Ages 11-14', 'Adult XS-XXL'],
      colors: ['Navy & White', 'Royal Blue', 'Maroon & Beige', 'White & Grey'],
      isCustomizable: true
    },
    {
      id: 'tm-105',
      title: 'Sublimation Magic Color-Changing Mug',
      category: 'mugs',
      categoryName: 'Mugs & Bottles',
      collection: 'col-mugs',
      rating: 4.9,
      reviewsCount: 215,
      badge: 'Hot Deal',
      image: 'assets/images/col-mugs.webp',
      desc: 'Heat-sensitive matte black ceramic mug that magically reveals your custom photo or logo when hot beverage is poured.',
      sizes: ['11 oz Standard'],
      colors: ['Magic Matte Black', 'Magic Gloss Black'],
      isCustomizable: true
    },
    {
      id: 'tm-106',
      title: 'Insulated Stainless Steel Sipper Bottle (750ml)',
      category: 'mugs',
      categoryName: 'Mugs & Bottles',
      collection: 'col-bottles',
      rating: 4.7,
      reviewsCount: 78,
      badge: 'New',
      image: 'assets/images/col-bottles.webp',
      desc: 'Double-walled vacuum insulated flask keeping beverages hot 12h or cold 24h. Laser-engraved name or full color sublimation.',
      sizes: ['750 ml'],
      colors: ['Gloss White', 'Matte Black', 'Silver Chrome'],
      isCustomizable: true
    },
    {
      id: 'tm-107',
      title: 'Custom LED Acrylic Photo Frame',
      category: 'led',
      categoryName: 'LED Frames & Decor',
      collection: 'col-led-frames',
      rating: 5.0,
      reviewsCount: 184,
      badge: 'Bestseller',
      image: 'assets/images/col-led-frames.webp',
      desc: 'Ultra-clear optical acrylic with warm golden LED wooden base. Includes power adapter and custom engraved photo and text.',
      sizes: ['6x8 Inches', '8x10 Inches'],
      colors: ['Warm Gold LED', 'Cool White LED', 'RGB Multi'],
      isCustomizable: true
    },
    {
      id: 'tm-108',
      title: 'Personalized Sequin Magic Cushion',
      category: 'gifts',
      categoryName: 'Custom Gifts & Decor',
      collection: 'col-magnets',
      rating: 4.7,
      reviewsCount: 89,
      badge: 'Trending',
      image: 'assets/images/col-magnets.webp',
      desc: 'Reversible sparkling sequin cushion cover with soft plush filler. Swipe up to reveal your hidden personalized design.',
      sizes: ['16x16 Inches'],
      colors: ['Gold / White', 'Silver / Black', 'Red / White'],
      isCustomizable: true
    },
    {
      id: 'tm-109',
      title: 'Custom Engraved Wooden Desk Stand & Clock',
      category: 'gifts',
      categoryName: 'Custom Gifts & Decor',
      collection: 'col-wooden',
      rating: 4.6,
      reviewsCount: 52,
      badge: 'Eco Friendly',
      image: 'assets/images/col-wooden.webp',
      desc: 'Crafted from premium pine MDF wood. Laser engraved with company logo, awards, family photo or calendar date.',
      sizes: ['Standard Desktop'],
      colors: ['Natural Oak', 'Dark Walnut'],
      isCustomizable: true
    },
    {
      id: 'tm-110',
      title: 'Metal & Acrylic Keychain Combo (Pack of 5)',
      category: 'gifts',
      categoryName: 'Custom Gifts & Decor',
      collection: 'col-keyrings',
      rating: 4.8,
      reviewsCount: 110,
      badge: 'Pack Deal',
      image: 'assets/images/col-keyrings.webp',
      desc: 'Double-sided sublimation metal keychain combo with glossy scratch-resistant coating. Ideal for school fests, cars & souvenirs.',
      sizes: ['Pack of 5'],
      colors: ['Silver Chrome', 'Gloss Acrylic'],
      isCustomizable: true
    },
    {
      id: 'tm-111',
      title: 'Custom Printed Branding Caps & Badges',
      category: 'apparel',
      categoryName: 'Apparel & Uniforms',
      collection: 'col-marking',
      rating: 4.5,
      reviewsCount: 47,
      badge: 'Staff & Events',
      image: 'assets/images/col-marking.webp',
      desc: 'Structured 5-panel cotton baseball caps with adjustable metal buckle and high-definition thermal vinyl or embroidered branding.',
      sizes: ['Free Size (Adjustable)'],
      colors: ['Black', 'White', 'Navy Blue'],
      isCustomizable: true
    },
    {
      id: 'tm-112',
      title: 'Complete Startup Sublimation Printing Machine Kit',
      category: 'bundles',
      categoryName: 'Startup & Machinery',
      collection: 'col-machines',
      rating: 4.9,
      reviewsCount: 56,
      badge: 'Business Setup',
      image: 'assets/images/col-machines.webp',
      desc: '5-in-1 combo heat press machine + 100 sublimation papers + thermal tape + sample raw blanks (mugs, t-shirts, frames) + training guide.',
      sizes: ['Commercial Kit'],
      colors: ['Industrial Standard'],
      isCustomizable: false
    }
  ];

  // Testimonials Data
  const TESTIMONIALS = [
    {
      quote: "TejasMade delivered 200 customized school polo uniforms and hoodies for our academy within 5 days. The fabric quality, stitching, and gold crest embroidery exceeded our expectations!",
      author: "Principal R. K. Sharma",
      role: "Oakridge Public Academy, Panipat",
      stars: 5
    },
    {
      quote: "We ordered 80 Corporate Gift Hampers with personalized insulated bottles and diaries for our annual employee summit. The packaging and finish were world-class.",
      author: "Pooja Singhania",
      role: "HR Director, TechSphere Solutions",
      stars: 5
    },
    {
      quote: "As a new entrepreneur starting a printing business, TejasMade supplied our 5-in-1 heat press machine and raw blanks at true wholesale rates with instant WhatsApp support on 9606799579.",
      author: "Amit Verma",
      role: "Founder, PrintCraft Studio, Haryana",
      stars: 5
    }
  ];

  // =========================================================================
  // 2. STATE MANAGEMENT (Cart / Inquiry List, Filter, Customizer, Auth)
  // =========================================================================
  let state = {
    cart: [],
    activeFilter: 'all',
    activeCollection: null,
    searchQuery: '',
    sortBy: 'featured',
    currentUser: null,
    currentPosterIndex: 0,
    currentTestimonialIndex: 0
  };

  const LS_CART_KEY = 'tejasmade_inquiry_items';
  const LS_USER_KEY = 'tejasmade_auth_user';

  function loadPersistedState() {
    try {
      const savedCart = localStorage.getItem(LS_CART_KEY);
      if (savedCart) {
        state.cart = JSON.parse(savedCart);
      }
      const savedUser = localStorage.getItem(LS_USER_KEY);
      if (savedUser) {
        state.currentUser = JSON.parse(savedUser);
      }
    } catch (e) {
      console.warn('Could not read from localStorage', e);
    }
  }

  function saveCartState() {
    try {
      localStorage.setItem(LS_CART_KEY, JSON.stringify(state.cart));
    } catch (e) {
      console.warn('Could not save cart to localStorage', e);
    }
  }

  // =========================================================================
  // 3. TOAST NOTIFICATIONS
  // =========================================================================
  function showToast(message, type = 'success') {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
        <polyline points="22 4 12 14.01 9 11.01"></polyline>
      </svg>
      <span>${message}</span>
    `;

    container.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(40px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 3200);
  }

  // =========================================================================
  // 4. HELLOBAR NOTICE TICKER
  // =========================================================================
  function initHellobarTicker() {
    const messages = document.querySelectorAll('.hellobar-message');
    if (!messages.length) return;

    let index = 0;
    setInterval(() => {
      messages[index].classList.remove('active');
      index = (index + 1) % messages.length;
      messages[index].classList.add('active');
    }, 4000);
  }

  // =========================================================================
  // 5. SLIDING POSTERS CAROUSEL CONTROLLER
  // =========================================================================
  function initSlidingPosters() {
    const track = document.getElementById('posterSlidesTrack');
    const prevBtn = document.getElementById('posterNavPrev');
    const nextBtn = document.getElementById('posterNavNext');
    const dots = document.querySelectorAll('.poster-dot');
    const totalSlides = dots.length;

    if (!track || totalSlides === 0) return;

    function goToSlide(idx) {
      state.currentPosterIndex = (idx + totalSlides) % totalSlides;
      track.style.transform = `translateX(-${state.currentPosterIndex * 100}%)`;

      dots.forEach((dot, i) => {
        dot.classList.toggle('active', i === state.currentPosterIndex);
      });
    }

    if (prevBtn) {
      prevBtn.addEventListener('click', () => goToSlide(state.currentPosterIndex - 1));
    }
    if (nextBtn) {
      nextBtn.addEventListener('click', () => goToSlide(state.currentPosterIndex + 1));
    }

    dots.forEach((dot, idx) => {
      dot.addEventListener('click', () => goToSlide(idx));
    });

    // Auto-advance posters every 5 seconds
    let posterInterval = setInterval(() => {
      goToSlide(state.currentPosterIndex + 1);
    }, 5000);

    const sliderContainer = document.getElementById('postersSlider');
    if (sliderContainer) {
      sliderContainer.addEventListener('mouseenter', () => clearInterval(posterInterval));
      sliderContainer.addEventListener('mouseleave', () => {
        clearInterval(posterInterval);
        posterInterval = setInterval(() => {
          goToSlide(state.currentPosterIndex + 1);
        }, 5000);
      });
    }
  }

  // =========================================================================
  // 6. NAVBAR SCROLL & MOBILE DRAWER
  // =========================================================================
  function initNavigation() {
    const header = document.querySelector('.site-header');
    const hamburgerBtn = document.getElementById('hamburgerBtn');
    const mainNav = document.getElementById('mainNav');
    const navLinks = document.querySelectorAll('.nav-link');

    window.addEventListener('scroll', () => {
      if (window.scrollY > 30) {
        header.classList.add('scrolled');
      } else {
        header.classList.remove('scrolled');
      }
    });

    if (hamburgerBtn && mainNav) {
      hamburgerBtn.addEventListener('click', () => {
        const isOpen = mainNav.classList.toggle('open');
        hamburgerBtn.classList.toggle('active', isOpen);
      });

      navLinks.forEach(link => {
        link.addEventListener('click', () => {
          mainNav.classList.remove('open');
          hamburgerBtn.classList.remove('active');
        });
      });
    }

    updateUserDisplay();
  }

  function updateUserDisplay() {
    const userBtnText = document.getElementById('userBtnText');
    if (!userBtnText) return;

    if (state.currentUser && state.currentUser.name) {
      userBtnText.textContent = `Hi, ${state.currentUser.name.split(' ')[0]}`;
    } else {
      userBtnText.textContent = 'Account';
    }
  }

  // =========================================================================
  // 7. RENDER PRODUCTS CATALOG (PRICES HIDDEN - FOCUS ON WHATSAPP & INQUIRY)
  // =========================================================================
  function getFilteredProducts() {
    return PRODUCTS_DATA.filter(item => {
      const matchesCategory =
        state.activeFilter === 'all' || item.category === state.activeFilter;

      const matchesCollection =
        !state.activeCollection || item.collection === state.activeCollection;

      const q = state.searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        item.title.toLowerCase().includes(q) ||
        item.desc.toLowerCase().includes(q) ||
        item.categoryName.toLowerCase().includes(q);

      return matchesCategory && matchesCollection && matchesSearch;
    }).sort((a, b) => {
      if (state.sortBy === 'rating') return b.rating - a.rating;
      return 0; // default featured
    });
  }

  function renderProductsGrid() {
    const grid = document.getElementById('productsGrid');
    if (!grid) return;

    const list = getFilteredProducts();

    if (list.length === 0) {
      grid.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 60px 20px; color: var(--text-secondary);">
          <p style="font-size: 1.3rem; margin-bottom: 8px;">No matching custom products found.</p>
          <p style="font-size: 0.9rem; color: var(--text-muted);">Try searching different terms or switch category filter.</p>
          <button class="btn btn-secondary btn-sm" style="margin-top: 18px;" id="resetFilterBtn">View All Products</button>
        </div>
      `;
      const resetBtn = document.getElementById('resetFilterBtn');
      if (resetBtn) {
        resetBtn.addEventListener('click', () => {
          state.activeFilter = 'all';
          state.activeCollection = null;
          state.searchQuery = '';
          const searchInput = document.getElementById('productSearchInput');
          if (searchInput) searchInput.value = '';
          document.querySelectorAll('.filter-tab').forEach(t => t.classList.toggle('active', t.dataset.filter === 'all'));
          renderProductsGrid();
        });
      }
      return;
    }

    grid.innerHTML = list.map(item => {
      return `
        <article class="product-card" data-id="${item.id}">
          <div class="product-thumb-container">
            ${item.badge ? `<span class="badge badge-gold product-card-badge">${item.badge}</span>` : ''}
            <img src="${item.image}" alt="${item.title}" class="product-thumb" loading="lazy" />
            <button class="product-quick-btn" data-action="quickview" data-id="${item.id}">Quick View</button>
          </div>
          <span class="product-category-tag">${item.categoryName}</span>
          <h3 class="product-card-title">${item.title}</h3>
          <p class="product-card-desc">${item.desc}</p>
          <div class="product-rating">
            ★ ★ ★ ★ ★ <span>${item.rating} (${item.reviewsCount} reviews)</span>
          </div>

          <!-- Product Price Hidden: Inquiry Tag Shown -->
          <div class="product-inquiry-tag">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
            Best Wholesale & Retail Quote on Inquiry
          </div>

          <div class="product-card-footer">
            <button class="btn btn-whatsapp btn-sm" data-action="direct-wa" data-id="${item.id}">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M20.52 3.449A11.915 11.915 0 0 0 12.062 0C5.46 0 .092 5.367.089 11.971c0 2.11.551 4.168 1.597 5.982L0 24l6.195-1.625a11.93 11.93 0 0 0 5.864 1.523h.005c6.599 0 11.97-5.368 11.973-11.973a11.91 11.91 0 0 0-3.517-8.476zM12.067 21.895h-.004a9.92 9.92 0 0 1-5.057-1.385l-.363-.215-3.76.986 1.003-3.665-.236-.375a9.88 9.88 0 0 1-1.517-5.267c.003-5.469 4.453-9.919 9.932-9.919 2.651.001 5.143 1.033 7.016 2.908a9.865 9.865 0 0 1 2.903 7.018c-.003 5.47-4.453 9.914-9.917 9.914z"/></svg>
              Order on WhatsApp
            </button>
            <button class="btn btn-secondary btn-sm" data-action="add-inquiry" data-id="${item.id}" title="Add to Order List">
              + Add to List
            </button>
          </div>
        </article>
      `;
    }).join('');

    // Attach card event listeners
    grid.querySelectorAll('[data-action="direct-wa"]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.getAttribute('data-id');
        orderItemDirectWhatsApp(id);
      });
    });

    grid.querySelectorAll('[data-action="add-inquiry"]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.getAttribute('data-id');
        addToCart(id, 1);
      });
    });

    grid.querySelectorAll('[data-action="quickview"]').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.getAttribute('data-id');
        openQuickViewModal(id);
      });
    });
  }

  function initProductFilters() {
    const tabs = document.querySelectorAll('.filter-tab');
    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        tabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        state.activeFilter = tab.getAttribute('data-filter');
        state.activeCollection = null;
        renderProductsGrid();
      });
    });

    const searchInput = document.getElementById('productSearchInput');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        state.searchQuery = e.target.value;
        renderProductsGrid();
      });
    }

    const sortSelect = document.getElementById('productSortSelect');
    if (sortSelect) {
      sortSelect.addEventListener('change', (e) => {
        state.sortBy = e.target.value;
        renderProductsGrid();
      });
    }

    // Collections grid clickable cards
    document.querySelectorAll('.collection-card').forEach(card => {
      card.addEventListener('click', () => {
        const colKey = card.getAttribute('data-collection');
        const catKey = card.getAttribute('data-category');

        state.activeCollection = colKey;
        if (catKey) state.activeFilter = catKey;

        tabs.forEach(t => {
          t.classList.toggle('active', t.getAttribute('data-filter') === (catKey || 'all'));
        });

        renderProductsGrid();

        const shopSection = document.getElementById('shop');
        if (shopSection) {
          shopSection.scrollIntoView({ behavior: 'smooth' });
        }

        showToast(`Showing collection items`);
      });
    });
  }

  // =========================================================================
  // 8. DIRECT WHATSAPP ORDERING & CART SYSTEM (PHONE: 9606799579)
  // =========================================================================
  function orderItemDirectWhatsApp(productId, options = {}) {
    const product = PRODUCTS_DATA.find(p => p.id === productId);
    if (!product) return;

    let msg = `*NEW ORDER INQUIRY — TEJAS MADE*\n`;
    msg += `------------------------------------\n`;
    msg += `• Product: *${product.title}*\n`;
    msg += `• Category: ${product.categoryName}\n`;
    if (options.size) msg += `• Preferred Size: ${options.size}\n`;
    if (options.color) msg += `• Preferred Color: ${options.color}\n`;
    if (options.customText) msg += `• Custom Name/Text: "${options.customText}"\n`;
    if (options.quantity) msg += `• Required Quantity: ${options.quantity} pcs\n`;
    msg += `------------------------------------\n`;
    msg += `Hello TejasMade, please share pricing and order confirmation for this custom item!`;

    const encoded = encodeURIComponent(msg);
    window.open(`https://wa.me/91${BUSINESS_PHONE}?text=${encoded}`, '_blank');
    showToast(`Opening WhatsApp (${BUSINESS_PHONE})...`);
  }

  function addToCart(productId, quantity = 1, options = {}) {
    const product = PRODUCTS_DATA.find(p => p.id === productId);
    if (!product) return;

    const size = options.size || (product.sizes ? product.sizes[0] : 'Standard');
    const color = options.color || (product.colors ? product.colors[0] : 'Default');
    const customText = options.customText || '';

    const existingIndex = state.cart.findIndex(
      item => item.id === productId && item.size === size && item.color === color && item.customText === customText
    );

    if (existingIndex > -1) {
      state.cart[existingIndex].quantity += quantity;
    } else {
      state.cart.push({
        id: product.id,
        title: product.title,
        image: product.image,
        quantity: quantity,
        size: size,
        color: color,
        customText: customText
      });
    }

    saveCartState();
    updateCartUI();
    showToast(`Added "${product.title}" to your order list!`);
    openCartDrawer();
  }

  function removeFromCart(index) {
    if (index >= 0 && index < state.cart.length) {
      const removed = state.cart.splice(index, 1);
      saveCartState();
      updateCartUI();
      if (removed.length) {
        showToast(`Removed "${removed[0].title}" from list`);
      }
    }
  }

  function updateItemQuantity(index, delta) {
    if (index >= 0 && index < state.cart.length) {
      state.cart[index].quantity += delta;
      if (state.cart[index].quantity <= 0) {
        removeFromCart(index);
        return;
      }
      saveCartState();
      updateCartUI();
    }
  }

  function updateCartUI() {
    const totalCount = state.cart.reduce((sum, item) => sum + item.quantity, 0);
    const badges = document.querySelectorAll('.cart-count-badge');
    badges.forEach(b => {
      b.textContent = totalCount;
      b.style.display = totalCount > 0 ? 'inline-flex' : 'none';
    });

    const itemsContainer = document.getElementById('cartItemsList');
    const emptyState = document.getElementById('cartEmptyState');
    const drawerFooter = document.getElementById('cartDrawerFooter');

    if (!itemsContainer) return;

    if (state.cart.length === 0) {
      if (emptyState) emptyState.style.display = 'flex';
      itemsContainer.innerHTML = '';
      if (drawerFooter) drawerFooter.style.display = 'none';
      return;
    }

    if (emptyState) emptyState.style.display = 'none';
    if (drawerFooter) drawerFooter.style.display = 'block';

    itemsContainer.innerHTML = state.cart.map((item, index) => {
      return `
        <div class="cart-item">
          <img src="${item.image}" alt="${item.title}" class="cart-item-img" />
          <div class="cart-item-info">
            <h4 class="cart-item-title">${item.title}</h4>
            <p class="cart-item-meta">
              ${item.size ? `Size: ${item.size} • ` : ''}${item.color ? `Color: ${item.color}` : ''}
              ${item.customText ? `<br/><span style="color:var(--gold-primary);">Custom: "${item.customText}"</span>` : ''}
            </p>
            <span class="cart-item-inquiry-status">Quantity: ${item.quantity} pcs (Factory Inquiry)</span>
          </div>
          <div class="cart-item-actions">
            <div class="qty-controls">
              <button class="qty-btn" onclick="window.TejasApp.changeQty(${index}, -1)">−</button>
              <span class="qty-val">${item.quantity}</span>
              <button class="qty-btn" onclick="window.TejasApp.changeQty(${index}, 1)">+</button>
            </div>
            <button class="cart-item-remove" onclick="window.TejasApp.removeItem(${index})">Remove</button>
          </div>
        </div>
      `;
    }).join('');
  }

  function checkoutViaWhatsApp() {
    if (state.cart.length === 0) {
      showToast('Your order list is empty!', 'warning');
      return;
    }

    let message = `*NEW BULK / CUSTOM ORDER INQUIRY — TEJAS MADE*\n`;
    message += `Custom Made. Just For You.\n\n`;
    message += `*REQUESTED PRODUCTS LIST:*\n`;

    state.cart.forEach((item, i) => {
      message += `${i + 1}. *${item.title}* (Qty: ${item.quantity} pcs)\n`;
      message += `   • Size: ${item.size} | Color: ${item.color}\n`;
      if (item.customText) {
        message += `   • Custom Text/Design: "${item.customText}"\n`;
      }
      message += `\n`;
    });

    message += `-------------------------\n`;
    if (state.currentUser && state.currentUser.name) {
      message += `*Customer:* ${state.currentUser.name} (${state.currentUser.phone || ''})\n`;
    }
    message += `Please provide your best wholesale quotation and production timeline for the above items.`;

    const encoded = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/91${BUSINESS_PHONE}?text=${encoded}`;

    window.open(whatsappUrl, '_blank');
    showToast(`Redirecting to WhatsApp (${BUSINESS_PHONE})...`);
  }

  function openCartDrawer() {
    const backdrop = document.getElementById('cartDrawerBackdrop');
    const drawer = document.getElementById('cartDrawer');
    if (backdrop && drawer) {
      backdrop.classList.add('active');
      drawer.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  }

  function closeCartDrawer() {
    const backdrop = document.getElementById('cartDrawerBackdrop');
    const drawer = document.getElementById('cartDrawer');
    if (backdrop && drawer) {
      backdrop.classList.remove('active');
      drawer.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  function initCartDrawerListeners() {
    const cartTriggerBtns = document.querySelectorAll('[data-action="open-cart"]');
    cartTriggerBtns.forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        openCartDrawer();
      });
    });

    const closeBtn = document.getElementById('cartDrawerClose');
    if (closeBtn) closeBtn.addEventListener('click', closeCartDrawer);

    const backdrop = document.getElementById('cartDrawerBackdrop');
    if (backdrop) backdrop.addEventListener('click', closeCartDrawer);

    const checkoutBtn = document.getElementById('whatsappCheckoutBtn');
    if (checkoutBtn) checkoutBtn.addEventListener('click', checkoutViaWhatsApp);
  }

  // =========================================================================
  // 9. INTERACTIVE LIVE CUSTOM DESIGN STUDIO
  // =========================================================================
  function initCustomDesignStudio() {
    const mockupImg = document.getElementById('mockupBaseImage');
    const mockupText = document.getElementById('mockupCustomText');
    const mockupUploadedImg = document.getElementById('mockupUploadedImg');
    const textInput = document.getElementById('studioTextInput');
    const fontSelect = document.getElementById('studioFontSelect');
    const customFileInput = document.getElementById('studioImageUpload');
    const productOptions = document.querySelectorAll('.studio-option-btn[data-product]');
    const colorSwatches = document.querySelectorAll('.color-swatch');
    const submitCustomBtn = document.getElementById('submitCustomRequestBtn');

    let studioState = {
      product: 'T-Shirt',
      color: 'Obsidian Black',
      customText: 'WEAR YOUR STORY',
      font: 'DM Sans',
      hasImage: false
    };

    const MOCKUP_MAP = {
      'T-Shirt': 'assets/images/col-tshirts.webp',
      'Hoodie': 'assets/images/col-fabrics.webp',
      'Magic Mug': 'assets/images/col-mugs.webp',
      'LED Photo Frame': 'assets/images/col-led-frames.webp',
      'Sipper Bottle': 'assets/images/col-bottles.webp',
      'Corporate Hamper': 'assets/images/col-corporate-gifts.jpg',
      'School Uniform': 'assets/images/col-school-uniform.jpg'
    };

    productOptions.forEach(btn => {
      btn.addEventListener('click', () => {
        productOptions.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        const prodName = btn.getAttribute('data-product');
        if (MOCKUP_MAP[prodName]) {
          studioState.product = prodName;
          if (mockupImg) mockupImg.src = MOCKUP_MAP[prodName];
        }
      });
    });

    colorSwatches.forEach(swatch => {
      swatch.addEventListener('click', () => {
        colorSwatches.forEach(s => s.classList.remove('active'));
        swatch.classList.add('active');
        studioState.color = swatch.getAttribute('data-color-name');

        const hex = swatch.getAttribute('data-color');
        const canvas = document.getElementById('mockupCanvas');
        if (canvas) {
          canvas.style.background = `radial-gradient(circle, ${hex}44 0%, #0d0e13 100%)`;
        }
      });
    });

    if (textInput && mockupText) {
      textInput.addEventListener('input', (e) => {
        const val = e.target.value.trim();
        mockupText.textContent = val || 'YOUR DESIGN HERE';
        studioState.customText = val;
      });
    }

    if (fontSelect && mockupText) {
      fontSelect.addEventListener('change', (e) => {
        mockupText.style.fontFamily = e.target.value;
        studioState.font = e.target.value;
      });
    }

    if (customFileInput && mockupUploadedImg) {
      customFileInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = function (event) {
            mockupUploadedImg.src = event.target.result;
            mockupUploadedImg.style.display = 'block';
            studioState.hasImage = true;
            showToast('Custom logo uploaded to preview!');
          };
          reader.readAsDataURL(file);
        }
      });
    }

    if (submitCustomBtn) {
      submitCustomBtn.addEventListener('click', (e) => {
        e.preventDefault();

        const nameInput = document.getElementById('customCustomerName');
        const phoneInput = document.getElementById('customCustomerPhone');
        const notesInput = document.getElementById('customNotes');

        const name = nameInput ? nameInput.value.trim() : '';
        const phone = phoneInput ? phoneInput.value.trim() : '';
        const notes = notesInput ? notesInput.value.trim() : '';

        if (!name || !phone) {
          showToast('Please provide your name and phone number.', 'warning');
          return;
        }

        let msg = `*CUSTOM DESIGN REQUEST — TEJAS MADE*\n`;
        msg += `------------------------------------\n`;
        msg += `• Product: *${studioState.product}*\n`;
        msg += `• Color: ${studioState.color}\n`;
        msg += `• Custom Text: "${studioState.customText || 'None'}"\n`;
        msg += `• Font Style: ${studioState.font}\n`;
        msg += `• Logo / Graphic: ${studioState.hasImage ? 'Yes (Will attach in chat)' : 'Text Only'}\n\n`;
        msg += `*CUSTOMER DETAILS:*\n`;
        msg += `• Name: ${name}\n`;
        msg += `• WhatsApp / Phone: ${phone}\n`;
        if (notes) msg += `• Notes / Quantity: ${notes}\n`;
        msg += `\nPlease review my custom design request and confirm pricing & delivery!`;

        const encoded = encodeURIComponent(msg);
        window.open(`https://wa.me/91${BUSINESS_PHONE}?text=${encoded}`, '_blank');
        showToast(`Sending custom request to WhatsApp (${BUSINESS_PHONE})...`);
      });
    }
  }

  // =========================================================================
  // 10. QUICK VIEW MODAL (NO PRICES - DIRECT WHATSAPP ACTION)
  // =========================================================================
  function openQuickViewModal(productId) {
    const product = PRODUCTS_DATA.find(p => p.id === productId);
    if (!product) return;

    const modal = document.getElementById('quickViewModal');
    if (!modal) return;

    modal.querySelector('#qvImage').src = product.image;
    modal.querySelector('#qvTitle').textContent = product.title;
    modal.querySelector('#qvCategory').textContent = product.categoryName;
    modal.querySelector('#qvDesc').textContent = product.desc;
    modal.querySelector('#qvRating').textContent = `★ ★ ★ ★ ★ ${product.rating} (${product.reviewsCount} reviews)`;

    const sizesBox = modal.querySelector('#qvSizesList');
    if (sizesBox && product.sizes) {
      sizesBox.innerHTML = product.sizes.map((s, idx) => `
        <button class="studio-option-btn ${idx === 0 ? 'active' : ''}" data-qv-size="${s}">${s}</button>
      `).join('');

      sizesBox.querySelectorAll('[data-qv-size]').forEach(btn => {
        btn.addEventListener('click', () => {
          sizesBox.querySelectorAll('[data-qv-size]').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
        });
      });
    }

    const colorsBox = modal.querySelector('#qvColorsList');
    if (colorsBox && product.colors) {
      colorsBox.innerHTML = product.colors.map((c, idx) => `
        <button class="studio-option-btn ${idx === 0 ? 'active' : ''}" data-qv-color="${c}">${c}</button>
      `).join('');

      colorsBox.querySelectorAll('[data-qv-color]').forEach(btn => {
        btn.addEventListener('click', () => {
          colorsBox.querySelectorAll('[data-qv-color]').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
        });
      });
    }

    const waBtn = modal.querySelector('#qvWhatsAppOrderBtn');
    if (waBtn) {
      waBtn.onclick = () => {
        const selectedSize = sizesBox ? sizesBox.querySelector('.active')?.getAttribute('data-qv-size') : 'Standard';
        const selectedColor = colorsBox ? colorsBox.querySelector('.active')?.getAttribute('data-qv-color') : 'Default';
        const customText = modal.querySelector('#qvCustomText')?.value || '';
        const qty = parseInt(modal.querySelector('#qvQtyInput')?.value, 10) || 1;

        orderItemDirectWhatsApp(product.id, {
          size: selectedSize,
          color: selectedColor,
          customText: customText,
          quantity: qty
        });

        closeModal(modal);
      };
    }

    const addListBtn = modal.querySelector('#qvAddToListBtn');
    if (addListBtn) {
      addListBtn.onclick = () => {
        const selectedSize = sizesBox ? sizesBox.querySelector('.active')?.getAttribute('data-qv-size') : 'Standard';
        const selectedColor = colorsBox ? colorsBox.querySelector('.active')?.getAttribute('data-qv-color') : 'Default';
        const customText = modal.querySelector('#qvCustomText')?.value || '';
        const qty = parseInt(modal.querySelector('#qvQtyInput')?.value, 10) || 1;

        addToCart(product.id, qty, {
          size: selectedSize,
          color: selectedColor,
          customText: customText
        });

        closeModal(modal);
      };
    }

    openModal(modal);
  }

  function openModal(modalEl) {
    if (!modalEl) return;
    modalEl.classList.add('active');
    document.body.style.overflow = 'hidden';
  }

  function closeModal(modalEl) {
    if (!modalEl) return;
    modalEl.classList.remove('active');
    document.body.style.overflow = '';
  }

  function initModalListeners() {
    document.querySelectorAll('.modal-overlay').forEach(modal => {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) closeModal(modal);
      });

      modal.querySelectorAll('[data-action="close-modal"]').forEach(btn => {
        btn.addEventListener('click', () => closeModal(modal));
      });
    });

    const userBtn = document.getElementById('userAccountBtn');
    const authModal = document.getElementById('authModal');
    if (userBtn && authModal) {
      userBtn.addEventListener('click', () => openModal(authModal));
    }

    const searchTrigger = document.getElementById('searchModalTrigger');
    const searchModal = document.getElementById('searchModal');
    if (searchTrigger && searchModal) {
      searchTrigger.addEventListener('click', () => {
        openModal(searchModal);
        const input = document.getElementById('globalSearchModalInput');
        if (input) setTimeout(() => input.focus(), 150);
      });
    }

    initGlobalSearchModal();
    initAuthModal();
  }

  // =========================================================================
  // 11. GLOBAL SEARCH MODAL (Instant Search)
  // =========================================================================
  function initGlobalSearchModal() {
    const input = document.getElementById('globalSearchModalInput');
    const resultsContainer = document.getElementById('globalSearchResults');
    if (!input || !resultsContainer) return;

    input.addEventListener('input', (e) => {
      const q = e.target.value.toLowerCase().trim();
      if (!q) {
        resultsContainer.innerHTML = '<p style="color:var(--text-muted);text-align:center;padding:20px;">Type keywords like "t-shirt", "corporate gifts", "school uniform", "mugs"...</p>';
        return;
      }

      const matches = PRODUCTS_DATA.filter(p =>
        p.title.toLowerCase().includes(q) ||
        p.desc.toLowerCase().includes(q) ||
        p.categoryName.toLowerCase().includes(q)
      );

      if (matches.length === 0) {
        resultsContainer.innerHTML = '<p style="color:var(--text-muted);text-align:center;padding:20px;">No matching custom products found.</p>';
        return;
      }

      resultsContainer.innerHTML = matches.map(item => `
        <div class="cart-item" style="cursor:pointer;" onclick="window.TejasApp.openItemAndCloseSearch('${item.id}')">
          <img src="${item.image}" alt="${item.title}" class="cart-item-img" />
          <div class="cart-item-info">
            <h4 class="cart-item-title">${item.title}</h4>
            <span class="product-category-tag">${item.categoryName}</span>
            <div style="font-size:0.75rem; color:var(--gold-primary);">★ Custom Quote on Inquiry</div>
          </div>
          <button class="btn btn-whatsapp btn-sm" onclick="event.stopPropagation(); window.TejasApp.orderOnWhatsApp('${item.id}')">
            WhatsApp
          </button>
        </div>
      `).join('');
    });
  }

  // =========================================================================
  // 12. MOCK AUTHENTICATION SYSTEM
  // =========================================================================
  function initAuthModal() {
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    const tabLogin = document.getElementById('tabLogin');
    const tabSignup = document.getElementById('tabSignup');
    const authModal = document.getElementById('authModal');

    if (tabLogin && tabSignup && loginForm && signupForm) {
      tabLogin.addEventListener('click', () => {
        tabLogin.classList.add('active');
        tabSignup.classList.remove('active');
        loginForm.style.display = 'flex';
        signupForm.style.display = 'none';
      });

      tabSignup.addEventListener('click', () => {
        tabSignup.classList.add('active');
        tabLogin.classList.remove('active');
        signupForm.style.display = 'flex';
        loginForm.style.display = 'none';
      });

      loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = document.getElementById('loginEmail').value.trim();
        const namePart = email.split('@')[0];
        state.currentUser = {
          name: namePart.charAt(0).toUpperCase() + namePart.slice(1),
          email: email
        };
        localStorage.setItem(LS_USER_KEY, JSON.stringify(state.currentUser));
        updateUserDisplay();
        closeModal(authModal);
        showToast(`Welcome back, ${state.currentUser.name}!`);
      });

      signupForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('signupName').value.trim();
        const email = document.getElementById('signupEmail').value.trim();
        const phone = document.getElementById('signupPhone').value.trim();
        state.currentUser = { name, email, phone };
        localStorage.setItem(LS_USER_KEY, JSON.stringify(state.currentUser));
        updateUserDisplay();
        closeModal(authModal);
        showToast(`Account created for ${name}! Welcome to TEJAS MADE.`);
      });
    }
  }

  // =========================================================================
  // 13. FAQ ACCORDION
  // =========================================================================
  function initFAQ() {
    const items = document.querySelectorAll('.faq-item');
    items.forEach(item => {
      const q = item.querySelector('.faq-question');
      if (q) {
        q.addEventListener('click', () => {
          const isActive = item.classList.contains('active');
          items.forEach(i => i.classList.remove('active'));
          if (!isActive) item.classList.add('active');
        });
      }
    });
  }

  // =========================================================================
  // 14. TESTIMONIALS SLIDER
  // =========================================================================
  function initTestimonials() {
    const track = document.getElementById('testimonialTrack');
    const prevBtn = document.getElementById('testimonialPrev');
    const nextBtn = document.getElementById('testimonialNext');
    if (!track) return;

    track.innerHTML = TESTIMONIALS.map(t => `
      <div class="testimonial-slide">
        <div class="testimonial-stars">★ ★ ★ ★ ★</div>
        <p class="testimonial-quote">“${t.quote}”</p>
        <h4 class="testimonial-author">${t.author}</h4>
        <p class="testimonial-role">${t.role}</p>
      </div>
    `).join('');

    function updateSlide() {
      track.style.transform = `translateX(-${state.currentTestimonialIndex * 100}%)`;
    }

    if (prevBtn) {
      prevBtn.addEventListener('click', () => {
        state.currentTestimonialIndex = (state.currentTestimonialIndex - 1 + TESTIMONIALS.length) % TESTIMONIALS.length;
        updateSlide();
      });
    }

    if (nextBtn) {
      nextBtn.addEventListener('click', () => {
        state.currentTestimonialIndex = (state.currentTestimonialIndex + 1) % TESTIMONIALS.length;
        updateSlide();
      });
    }

    setInterval(() => {
      state.currentTestimonialIndex = (state.currentTestimonialIndex + 1) % TESTIMONIALS.length;
      updateSlide();
    }, 6000);
  }

  // =========================================================================
  // 15. CONTACT & NEWSLETTER FORMS
  // =========================================================================
  function initForms() {
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
      contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = document.getElementById('contactName')?.value || 'Friend';
        const phone = document.getElementById('contactPhone')?.value || '';
        const msg = document.getElementById('contactMessage')?.value || '';

        // Open WhatsApp directly with the inquiry
        let waText = `*NEW CONTACT MESSAGE — TEJAS MADE*\n`;
        waText += `• From: ${name}\n`;
        waText += `• Phone: ${phone}\n`;
        waText += `• Message: ${msg}\n`;

        window.open(`https://wa.me/91${BUSINESS_PHONE}?text=${encodeURIComponent(waText)}`, '_blank');
        showToast(`Thank you, ${name}! Redirecting to WhatsApp (${BUSINESS_PHONE})...`);
        contactForm.reset();
      });
    }

    const newsletterForm = document.getElementById('newsletterForm');
    if (newsletterForm) {
      newsletterForm.addEventListener('submit', (e) => {
        e.preventDefault();
        showToast('Subscribed! You will receive wholesale discount alerts & new collection notices.');
        newsletterForm.reset();
      });
    }
  }

  // =========================================================================
  // 16. GLOBAL EXPORTS & INITIALIZATION
  // =========================================================================
  window.TejasApp = {
    changeQty: updateItemQuantity,
    removeItem: removeFromCart,
    orderOnWhatsApp: (id) => orderItemDirectWhatsApp(id),
    openItemAndCloseSearch: (id) => {
      const searchModal = document.getElementById('searchModal');
      if (searchModal) closeModal(searchModal);
      openQuickViewModal(id);
    }
  };

  document.addEventListener('DOMContentLoaded', () => {
    loadPersistedState();
    initHellobarTicker();
    initSlidingPosters();
    initNavigation();
    initProductFilters();
    renderProductsGrid();
    initCartDrawerListeners();
    updateCartUI();
    initCustomDesignStudio();
    initModalListeners();
    initFAQ();
    initTestimonials();
    initForms();

    console.log('TejasMade E-Commerce loaded cleanly with 9606799579 & animated branding.');
  });
})();
